#! /bin/bash

## Script for building dockerfiles and executing kubernetes templates

cd app
docker build -t . myapplication:v1.0

cd ../web
docker build -t . mywebapplication:v1.0

cd ../db
kubectl create secret generic db-secret --from-file=password=password.txt

cd ../kubernetes
kubectl apply -f .