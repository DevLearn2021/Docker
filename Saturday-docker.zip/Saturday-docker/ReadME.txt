1. install.sh -- for creating docker images locally 
2. app folder - contains server.py which is a flask server running backend.
3. db folder - contains the password file for logging into MYSQL db created using image.
4. web folder - contains the frontend application. 
5. kubernetes folder - It contains yaml files for creating the respective kubernetes objects.
a. app.yaml - YAML file for application. It maps the service for using the app container on port 8080
b. db.yaml - creates mysql db pod, deployment, PV and PVC.
c. web.yaml - creates a service and a deployment for web frontend application.