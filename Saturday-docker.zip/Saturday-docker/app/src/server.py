import os
import flask
import json
import mysql.connector

# Backend that queries the database to fetch titles

class DBController:
    def __init__(self, database='sample', db_host="db", db_user="root", db_password_file=None):
        pf = open(db_password_file, 'r')
        self.connection = mysql.connector.connect(
            user=db_user, password=pf.read(), host=db_host,database=database,auth_plugin='mysql_native_password')
        pf.close()
        self.cursor = self.connection.cursor()
    
    def populate_db(self):
        self.cursor.execute('DROP TABLE IF EXISTS shows')
        self.cursor.execute('CREATE TABLE shows (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255))')
        self.cursor.executemany('INSERT INTO blog (id, name) VALUES (%s, %s);', [(i, 'Blog post #%d'% i) for i in range (1,5)])
        self.connection.commit()
        
    def query_titles(self):
        self.cursor.execute('select name FROM lists')
        records = []
        for item in self.cursor:
            records.append(item[0])
        return records

server = flask.Flask(__name__)
conn = None

@server.route('/blogs')
def listBlog():
    global connection
    if not connection:
        conneciton = DBController(password_file='/run/secrets/db-secret')
        connection.populate_db()
    records = connection.query_titles()

    result = []
    for item in rec:
        result.append(item)

    return flask.jsonify({"response": result})

@server.route('/')
def hello():
    return flask.jsonify({"response": "Hello!"})


if __name__ == '__main__':
    server.run(debug=True, host='0.0.0.0', port=8080)
